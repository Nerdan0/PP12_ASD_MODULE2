import java.util.Scanner;

public class Task_2 {

    public static int size_1;
    public static Stack stack_1;

    public static int size_2;
    public static Stack stack_2;

    public static int size_3;
    public static Stack stack_3;

    static public int[] getSegments(Stack stack) {
        int[] segments = new int[stack.count()];
        for (int i=0; i < segments.length; i++)
            segments[i] = stack.getSumOnSegment(i+1);
        return segments;
    }

    public static class Stack{
        private int max_size;
        private int[] stack_array;
        private int end_num;

        public Stack(int max_size){
            this.max_size=max_size;
            stack_array = new int[max_size];
            end_num=-1;
        }

        public void Push(int element){
            stack_array[++end_num] = element;
        }

        public int getSumOnSegment(int end) {
            int sum = 0;
            for (int i=0; i < end; i++)
                sum += stack_array[i];
            return sum;
        }

        public int count() {
            return end_num + 1;
        }

    }

    public static void main(String[] args) {

        System.out.println("Введите размер стэка  1");
        Scanner Input = new Scanner(System.in);
        size_1 = Input.nextInt();
        stack_1 = new Stack(size_1);
        System.out.println("Введите размер стэка  2");
        size_2 = Input.nextInt();
        stack_2 = new Stack(size_2);
        System.out.println("Введите размер стэка  3");
        size_3 = Input.nextInt();
        stack_3 = new Stack(size_3);

        for(int i : stack_1.stack_array) {
            System.out.println("Введите число для 1 стэка");
            int value = Input.nextInt();
            stack_1.Push(value);
        }
        for(int i : stack_2.stack_array) {
            System.out.println("Введите число для 2 стэка");
            int value = Input.nextInt();
            stack_2.Push(value);
        }
        for(int i : stack_3.stack_array) {
            System.out.println("Введите число для 3 стэка");
            int value = Input.nextInt();
            stack_3.Push(value);
        }

        int[] segments_1 = getSegments(stack_1);
        int[] segments_2 = getSegments(stack_2);
        int[] segments_3 = getSegments(stack_3);

        int max = 0;

        for (int i = 0; i < segments_1.length; i++)
            for (int j = 0; j < segments_2.length; j++)
                for (int k = 0; k < segments_3.length; k++)
                    if (segments_1[i] == segments_2[j] && segments_2[j] == segments_3[k]) {
                        max = segments_1[i];
                    }

        System.out.printf("Максимальный общий вес - %d\n", max);
    }
}