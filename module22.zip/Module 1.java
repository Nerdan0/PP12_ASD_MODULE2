package com.company;

import java.util.Scanner;

// pp-12
// Gandzeychuk
// Variant 6(4)

class main {
    public static int size;
    public static Stack stack;

    static int getInt() {
        int choise_num;
        while (true) {
            final Scanner num = new Scanner(System.in);
            if (num.hasNextInt()) {
                choise_num = num.nextInt();
                break;
            }
            System.out.println("enter integer number");
        }
        return choise_num;
    }

    public static class Stack{
        private int maxSize;
        private int[] stackArray;
        private int endNum;

        public Stack(int maxSize){
            this.maxSize=maxSize;
            stackArray = new int[maxSize];
            endNum=-1;
        }
        public void Push(int element){
            if(!isFull()) {
                stackArray[++endNum] = element;
            }
            else{
                System.out.println("Steck is full");
            }
        }
        public int Pop(){
            if(!isEmpty()) {
                return stackArray[endNum--];
            }
            else{
                System.out.println("Steck is empty");
                return 0;
            }
        }
        public int max(){
            int max = Integer.MIN_VALUE;
            for (int value : stackArray) {
                if (value > max)
                    max = value;
            }
            return max;
        }
        public int getEnd(){
            return stackArray[endNum];
        }
        public boolean isEmpty(){
            return (endNum==-1);
        }
        public boolean isFull(){
            return (endNum == maxSize-1);
        }
        public void showStack(){
            for(int i=0; i<maxSize; i++){
                System.out.println("Stack ["+(i+1)+"]"+"\t"+stackArray[i]);
            }
        }
    }

    public  static void method1(){
        System.out.println("method 1");
        int element = getInt();
        stack.Push(element);
    }
    public static void method2(){
        System.out.println("metod 2");
        stack.Pop();
    }
    public static void method3(){
        System.out.println("method 3");
        int max = stack.max();
        if(max!=Integer.MIN_VALUE)
            System.out.println("max value is - " + max);
        else System.out.println("elements are not found");
    }
    public static void menuStack(){
        System.out.println("enter steck value");
        size = getInt();
        stack = new Stack(size);
        int switch_number;
        do {
            System.out.println("enter method, 0 - exit");
            switch_number=getInt();
            switch (switch_number) {
                case 1:
                    method1();
                    break;
                case 2:
                    method2();
                    break;
                case 3:
                    method3();
                    break;
                case 0:
                    System.out.println("bye");
                    break;
            }
        }
        while (switch_number!=0);
        stack.showStack();
    }
    public static void main(String[] args) {
        menuStack();
    }
}